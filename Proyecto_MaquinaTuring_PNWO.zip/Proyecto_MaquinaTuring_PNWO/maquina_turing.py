import json
import time
from cinta import Cinta
from estado import Estado

#Esta implementación permite simular el comportamiento paso a paso o ejecutar el proceso completo hasta que la máquina se detenga.
class TuringMachine:

    #Inicializa una nueva máquina de Turing.
    def __init__(self, cinta: Cinta, estados: list, estado_inicial: str):
        self.cinta = cinta
        self.estados = {e.nombre: e for e in estados}
        self.estado_actual = self.estados[estado_inicial]
        self.finalizado = False

    #Ejecuta un único paso (una transición) de la máquina de Turing.
    def paso(self):
        if self.finalizado:
            return {
                "estado": self.estado_actual.nombre,
                "cinta": self.cinta.snapshot(),
                "finalizado": True,
                "aceptada": self.estado_actual.es_final
            }

        simbolo = self.cinta.leer()
        trans = self.estado_actual.obtener_transicion(simbolo)
        if not trans:
            self.finalizado = True
        else:
            escribir, mover, siguiente = trans
            self.cinta.escribir(escribir)
            self.cinta.mover(mover)
            self.estado_actual = self.estados.get(siguiente, self.estado_actual)

        return {
            "estado": self.estado_actual.nombre,
            "cinta": self.cinta.snapshot(),
            "finalizado": self.finalizado,
            "aceptada": self.estado_actual.es_final
        }
    #La ejecución continúa aplicando transiciones válidas hasta que la máquina no tenga una transición posible o llegue a un estado final.
    def ejecutar(self):
        while not self.finalizado:
            self.paso()
        return self.estado_actual.es_final

    #Incluye toda la información necesaria para restaurar la máquina posteriormente: la cinta, posición del cabezal, estados, transiciones y estado actual.
    def serializar(self):
        data = {
            "cinta": self.cinta.cinta,
            "pos": self.cinta.pos,
            "estado": self.estado_actual.nombre,
            "finalizado": self.finalizado,
            "estados": {
                nombre: {
                    "es_final": e.es_final,
                    "transiciones": {
                        s: [w, d, nxt] for s, (w, d, nxt) in e.transiciones.items()
                    },
                }
                for nombre, e in self.estados.items()
            },
        }
        return json.dumps(data)

    #Restaura una máquina de Turing a partir de una cadena JSON.
    @staticmethod
    def deserializar(data_json):
        data = json.loads(data_json)
        estados = []
        for nombre, info in data["estados"].items():
            e = Estado(nombre, info["es_final"])
            for s, (w, d, nxt) in info["transiciones"].items():
                e.agregar_transicion(s, w, d, nxt)
            estados.append(e)
        cinta = Cinta("")
        cinta.cinta = data["cinta"]
        cinta.pos = data["pos"]
        tm = TuringMachine(cinta, estados, data["estado"])
        tm.finalizado = data["finalizado"]
        return tm
