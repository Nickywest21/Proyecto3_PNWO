
#Representa la cinta de una máquina de Turing.
class Cinta:

    #Inicializa la cinta con una cadena de entrada.
    def __init__(self, cadena):
        self.cinta = list(cadena) + ["_"] * 3
        self.pos = 0

    #Lee el símbolo actual bajo el cabezal.
    def leer(self):
        return self.cinta[self.pos]

    # Escribe un símbolo en la posición actual de la cinta.
    def escribir(self, simbolo):
        self.cinta[self.pos] = simbolo

    #Mueve el cabezal de la cinta según la dirección indicada.
    def mover(self, direccion):
        if direccion == "R":
            self.pos += 1
            if self.pos >= len(self.cinta):
                self.cinta.append("_")
        elif direccion == "L":
            if self.pos == 0:
                self.cinta.insert(0, "_")
            else:
                self.pos -= 1
        
    #Devuelve una vista parcial de la cinta, centrada en la posición actual.
    def snapshot(self, ventana=15):
        inicio = max(0, self.pos - ventana // 2)
        fin = min(len(self.cinta), inicio + ventana)
        segment = self.cinta[inicio:fin]
        out = []
        for i, s in enumerate(segment, start=inicio):
            if i == self.pos:
                out.append(f"[{s}]")
            else:
                out.append(s)
        return " ".join(out)

    # Devuelve la representación completa de la cinta.
    def __str__(self):
        return "".join(self.cinta)
