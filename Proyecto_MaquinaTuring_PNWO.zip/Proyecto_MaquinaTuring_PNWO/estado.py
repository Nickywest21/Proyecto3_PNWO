#Representa un estado dentro de una máquina de Turing o un autómata finito.
class Estado:

    #Inicializa un nuevo estado.
    def __init__(self, nombre, es_final=False):
        self.nombre = nombre
        self.transiciones = {}
        self.es_final = es_final

    #Agrega una nueva transición desde este estado.
    def agregar_transicion(self, simbolo_lectura, simbolo_escritura, direccion, siguiente_estado):
        self.transiciones[simbolo_lectura] = (simbolo_escritura, direccion, siguiente_estado)

    #Obtiene la transición asociada a un símbolo dado.
    def obtener_transicion(self, simbolo):
        return self.transiciones.get(simbolo, None)


