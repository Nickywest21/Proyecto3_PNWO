# Representa un token individual generado durante el análisis léxico.

class Token:

    #Inicializa un nuevo token con su valor y tipo.
    def __init__(self, valor, tipo):
        self.valor = valor
        self.tipo = tipo

    #Retorna una representación en cadena del token.
    def __repr__(self):
        return f"[{self.valor} : {self.tipo}]"
