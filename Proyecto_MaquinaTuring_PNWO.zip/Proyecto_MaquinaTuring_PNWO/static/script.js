let sessionId = null;
let posCabezal = 0;

async function iniciar() {
    const cadena = document.getElementById("cadena").value;
    const res = await fetch("/start", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({cadena})
    });
    const data = await res.json();
    sessionId = data.session;
    actualizarVista(data.status);
}

async function paso() {
    if (!sessionId) return alert("Primero ejecuta la máquina");
    const res = await fetch("/step", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({session: sessionId})
    });
    const data = await res.json();
    actualizarVista(data);
}

async function reiniciar() {
    if (!sessionId) return;
    await fetch("/reset", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({session: sessionId})
    });
    sessionId = null;
    document.getElementById("cinta").textContent = "";
    document.getElementById("estado").textContent = "";
    document.getElementById("resultado").textContent = "";
}

function actualizarVista(status) {
    document.getElementById("cinta").textContent = status.cinta;
    document.getElementById("estado").textContent = status.estado;
    if (status.halted) {
        document.getElementById("resultado").textContent =
            status.aceptada ? "✅ Aceptada" : "❌ Rechazada";
    } else {
        document.getElementById("resultado").textContent = "Procesando...";
    }
}
