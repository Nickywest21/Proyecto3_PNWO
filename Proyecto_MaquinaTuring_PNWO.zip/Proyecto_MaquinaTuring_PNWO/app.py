from flask import Flask, render_template, request, session, jsonify
from cinta import Cinta
from estado import Estado
from maquina_turing import TuringMachine

app = Flask(__name__)
app.secret_key = "clave-secreta"

#Crea una máquina de Turing configurada según el lenguaje seleccionado.
def crear_maquina(cadena, lenguaje):
    # (a|b)*abb
    if lenguaje == "a":
        q0 = Estado("q0")
        q1 = Estado("q1")
        q2 = Estado("q2")
        q3 = Estado("q3")
        qf = Estado("qf", es_final=True)

        q0.agregar_transicion("a", "a", "R", "q0")
        q0.agregar_transicion("b", "b", "R", "q0")
        q0.agregar_transicion("_", "_", "L", "q1")

        q1.agregar_transicion("b", "b", "L", "q2")
        q2.agregar_transicion("b", "b", "L", "q3")
        q3.agregar_transicion("a", "a", "N", "qf")

        estados = [q0, q1, q2, q3, qf]
        return TuringMachine(Cinta(cadena), estados, "q0")

    # 0*1*
    elif lenguaje == "b":
        q0 = Estado("q0")
        q1 = Estado("q1")
        qf = Estado("qf", es_final=True)

        q0.agregar_transicion("0", "0", "R", "q0")
        q0.agregar_transicion("1", "1", "R", "q1")
        q1.agregar_transicion("1", "1", "R", "q1")
        q1.agregar_transicion("_", "_", "N", "qf")

        return TuringMachine(Cinta(cadena), [q0, q1, qf], "q0")

    # (ab)*
    elif lenguaje == "c":
        q0 = Estado("q0")
        q1 = Estado("q1")
        qf = Estado("qf", es_final=True)

        q0.agregar_transicion("a", "a", "R", "q1")
        q1.agregar_transicion("b", "b", "R", "q0")
        q0.agregar_transicion("_", "_", "N", "qf")

        return TuringMachine(Cinta(cadena), [q0, q1, qf], "q0")

    # 1(01)*0
    elif lenguaje == "d":
        q0 = Estado("q0")
        q1 = Estado("q1")
        q2 = Estado("q2")
        qf = Estado("qf", es_final=True)

        q0.agregar_transicion("1", "1", "R", "q1")
        q1.agregar_transicion("0", "0", "R", "q2")
        q2.agregar_transicion("1", "1", "R", "q1")
        q1.agregar_transicion("0", "0", "N", "qf")

        return TuringMachine(Cinta(cadena), [q0, q1, q2, qf], "q0")

    # (a+b)*a(a+b)*
    elif lenguaje == "e":
        q0 = Estado("q0")
        q1 = Estado("q1", es_final=True)

        q0.agregar_transicion("a", "a", "R", "q1")
        q0.agregar_transicion("b", "b", "R", "q0")
        q1.agregar_transicion("a", "a", "R", "q1")
        q1.agregar_transicion("b", "b", "R", "q1")
        q1.agregar_transicion("_", "_", "N", "q1")

        return TuringMachine(Cinta(cadena), [q0, q1], "q0")

    return None

#Ruta principal del servidor web.
@app.route("/")
def index():
    session.clear()
    return render_template("index.html")

#Inicializa una máquina de Turing con la cadena y el lenguaje seleccionados.
@app.route("/iniciar", methods=["POST"])
def iniciar():
    cadena = request.form["cadena"]
    lenguaje = request.form["lenguaje"]
    maquina = crear_maquina(cadena, lenguaje)

    if not maquina:
        return jsonify({"error": "Lenguaje inválido"})

    session["maquina"] = maquina.serializar()
    return jsonify({
        "estado": maquina.estado_actual.nombre,
        "cinta": maquina.cinta.snapshot()
    })

# Ejecuta un único paso de la máquina de Turing almacenada en la sesión.
@app.route("/paso", methods=["POST"])
def paso():
    data = session.get("maquina")
    if not data:
        return jsonify({"error": "No hay máquina inicializada"})
    maquina = TuringMachine.deserializar(data)
    maquina.paso()
    session["maquina"] = maquina.serializar()
    return jsonify({
        "estado": maquina.estado_actual.nombre,
        "cinta": maquina.cinta.snapshot(),
        "finalizado": maquina.finalizado,
        "aceptada": maquina.estado_actual.es_final
    })

#Limpia la sesión actual y devuelve un mensaje de confirmación.
@app.route("/reiniciar", methods=["POST"])
def reiniciar():
    session.clear()
    return jsonify({"mensaje": "Máquina reiniciada"})


if __name__ == "__main__":
    app.run(debug=True)
